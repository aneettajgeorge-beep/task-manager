# guac 🌿
A responsive React to-do list website inspired by the guac pastel abstract design.

## Run
npm install
npm run dev

## Build
npm run build

## GitHub
Push this project to a GitHub repository, then deploy with GitHub Pages, Netlify, or Vercel.
